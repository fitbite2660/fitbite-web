import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Fit Bite - Vers gemaakt, op maat ❤',
  description: 'Online bestellen bij Fit Bite. Poké bowls, smoothies, dranken & meer. Afhaling of bezorging.',
  viewport: 'width=device-width, initial-scale=1',
  manifest: '/manifest.json',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="nl">
      <head>
        <meta name="theme-color" content="#2d5f2e" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
      </head>
      <body>{children}</body>
    </html>
  );
}
