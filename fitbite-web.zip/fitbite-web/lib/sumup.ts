export interface SumUpCheckoutRequest {
  amount: number;
  currency: string;
  checkout_reference: string;
  pay_to_email: string;
  customer_email?: string;
  customer_phone?: string;
  return_url: string;
  decline_url: string;
  notify_url?: string;
  description: string;
}

export const MERCHANT_ID = process.env.NEXT_PUBLIC_SUMUP_MERCHANT_ID || 'M5VYY878';
const API_TOKEN = process.env.SUMUP_API_TOKEN;

export async function createSumUpCheckout(
  request: SumUpCheckoutRequest
): Promise<{ checkout_url: string; checkout_id: string }> {
  try {
    const response = await fetch('https://api.sumup.com/v0.1/checkouts', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${API_TOKEN}`,
      },
      body: JSON.stringify({
        ...request,
        pay_to_email: MERCHANT_ID === 'M5VYY878' ? 'vincent.meert@gmail.com' : request.pay_to_email,
      }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(`SumUp API Error: ${error.error_message || 'Unknown error'}`);
    }

    const data = await response.json();
    return {
      checkout_url: data.checkout_url,
      checkout_id: data.id,
    };
  } catch (error) {
    console.error('SumUp Error:', error);
    throw error;
  }
}

export function generateCheckoutReference(orderId: string): string {
  return `fitbite-${orderId}-${Date.now()}`;
}
