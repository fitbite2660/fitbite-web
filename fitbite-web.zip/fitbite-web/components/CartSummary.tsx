'use client';

import { useCartStore } from '@/lib/store';
import styles from './CartSummary.module.css';

export default function CartSummary() {
  const items = useCartStore((state) => state.items);
  const removeItem = useCartStore((state) => state.removeItem);
  const updateQuantity = useCartStore((state) => state.updateQuantity);

  return (
    <div className={styles.summary}>
      <h3>Winkelwagen ({items.length} items)</h3>
      <div className={styles.items}>
        {items.map((item) => (
          <div key={item.cartId} className={styles.item}>
            <div className={styles.info}>
              <p className={styles.name}>{item.name}</p>
              {item.customization && (
                <p className={styles.custom}>
                  Aangepast: {item.customization.basis && 'basis, '}
                  {item.customization.veggies?.length > 0 && `${item.customization.veggies.length} groenten, `}
                  {item.customization.toppings?.length > 0 && `${item.customization.toppings.length} toppings`}
                </p>
              )}
            </div>
            <div className={styles.controls}>
              <button
                className={styles.btn}
                onClick={() => updateQuantity(item.cartId, item.quantity - 1)}
              >
                −
              </button>
              <span className={styles.qty}>{item.quantity}</span>
              <button
                className={styles.btn}
                onClick={() => updateQuantity(item.cartId, item.quantity + 1)}
              >
                +
              </button>
            </div>
            <div className={styles.price}>€{(item.price * item.quantity).toFixed(2)}</div>
            <button
              className={styles.remove}
              onClick={() => removeItem(item.cartId)}
              title="Verwijderen"
            >
              ✕
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
