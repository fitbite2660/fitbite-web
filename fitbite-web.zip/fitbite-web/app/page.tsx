'use client';

import { useState, useMemo } from 'react';
import Link from 'next/link';
import { PRODUCTS, CUSTOMIZE_OPTIONS, SHOP_INFO } from '@/lib/products';
import { useCartStore } from '@/lib/store';
import ProductCard from '@/components/ProductCard';
import CartPreview from '@/components/CartPreview';
import CustomizeModal from '@/components/CustomizeModal';
import styles from './page.module.css';

const CATEGORIES = [
  'Poké bowls',
  'Custom bowls',
  'Korean fried chicken',
  'Smoothies',
  'Huisgemaakt smoothie',
  'Koude dranken',
];

export default function Home() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [customizeProduct, setCustomizeProduct] = useState<any>(null);
  const cartStore = useCartStore();

  const filteredProducts = useMemo(() => {
    if (!selectedCategory) return PRODUCTS;
    return PRODUCTS.filter((p) => p.category === selectedCategory);
  }, [selectedCategory]);

  const groupedProducts = useMemo(() => {
    const groups: { [key: string]: typeof PRODUCTS } = {};
    filteredProducts.forEach((product) => {
      if (!groups[product.category]) {
        groups[product.category] = [];
      }
      groups[product.category].push(product);
    });
    return groups;
  }, [filteredProducts]);

  const handleAddToCart = (product: any) => {
    if (product.customizable) {
      setCustomizeProduct(product);
    } else {
      cartStore.addItem(product);
    }
  };

  const handleCustomizeSubmit = (customization: any) => {
    if (customizeProduct) {
      cartStore.addItem(customizeProduct, customization);
      setCustomizeProduct(null);
    }
  };

  return (
    <main className={styles.home}>
      {/* Header */}
      <header className={styles.header}>
        <div className="container">
          <div className={styles.headerContent}>
            <div>
              <h1>{SHOP_INFO.name}</h1>
              <p className={styles.tagline}>{SHOP_INFO.tagline}</p>
            </div>
            <CartPreview />
          </div>
        </div>
      </header>

      {/* Category Filter */}
      <div className={styles.categoryFilter}>
        <div className="container">
          <button
            className={`${styles.categoryBtn} ${!selectedCategory ? styles.active : ''}`}
            onClick={() => setSelectedCategory(null)}
          >
            Alles
          </button>
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              className={`${styles.categoryBtn} ${selectedCategory === cat ? styles.active : ''}`}
              onClick={() => setSelectedCategory(cat)}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Products */}
      <div className="container">
        <section className="section">
          {Object.entries(groupedProducts).map(([category, products]) => (
            <div key={category} className={styles.categorySection}>
              <h2 className={styles.categoryTitle}>{category}</h2>
              <div className={styles.productGrid}>
                {products.map((product) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    onAddToCart={handleAddToCart}
                  />
                ))}
              </div>
            </div>
          ))}
        </section>
      </div>

      {/* Info Footer */}
      <footer className={styles.footer}>
        <div className="container">
          <div className={styles.footerInfo}>
            <div>
              <h3>Afhaling</h3>
              <p>{SHOP_INFO.address}</p>
            </div>
            <div>
              <h3>Contact</h3>
              <p>📞 {SHOP_INFO.phone}</p>
            </div>
            <div>
              <h3>Bezorging</h3>
              <p>Puurs, Willebroek, Boom: €25+<br />
              Bornem, Tisselt: €30+<br />
              Londerzeel, Niel-Schelle, Buggenhout: €50+</p>
            </div>
          </div>
        </div>
      </footer>

      {/* Customize Modal */}
      {customizeProduct && (
        <CustomizeModal
          product={customizeProduct}
          onSubmit={handleCustomizeSubmit}
          onClose={() => setCustomizeProduct(null)}
        />
      )}
    </main>
  );
}
