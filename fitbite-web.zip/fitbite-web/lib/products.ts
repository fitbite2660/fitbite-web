export interface Product {
  id: string;
  name: string;
  price: number;
  category: string;
  description?: string;
  customizable?: boolean;
  unavailable?: boolean;
}

export interface CustomizeOption {
  id: string;
  name: string;
  price: number;
}

export const PRODUCTS: Product[] = [
  // Poké bowls
  { id: 'pb-med', name: 'Poké bowl medium', price: 11.50, category: 'Poké bowls', description: 'Witte sushirijst met verse groenten — stel zelf samen', customizable: true },
  { id: 'pb-large', name: 'Poké bowl large', price: 13.50, category: 'Poké bowls', description: 'Grotere portie — zelfde keuzes', customizable: true },
  
  // Custom bowls
  { id: 'pbcustom-prot', name: 'Protein bowl', price: 16.75, category: 'Custom bowls', description: 'Rijst kip in plaats van rijst, waarop de bowl rijk aan eiwitten en laag in calori…' },
  { id: 'pbcustom-chick-teriyaki', name: 'Chicken teriyaki bowl', price: 14.75, category: 'Custom bowls', description: 'Rijst kip * edamame, komkommer, mais en rode ui * Saus: teriyakisaus…' },
  { id: 'pbcustom-bbq', name: 'BBQ Chicken Bowl', price: 15.75, category: 'Custom bowls', description: 'Rijst *kip * mais, komkommer, tomaat,rode ui en avocado* BBQ saus en mayo* crispy ui' },
  { id: 'pbcustom-spicy', name: 'Spicy chicken bowl', price: 15.75, category: 'Custom bowls', description: 'Rijst*kip*Komkommer, mais, mango, rode ui en avocado* spicy mayo *crispy ui' },
  { id: 'pbcustom-salmon', name: 'Smoked salmon bowl', price: 14.75, category: 'Custom bowls', description: 'Rijst*gerookte zalm* Avocado, komkommer, rode ui, edamame en tomaat* teriyaki en siracha mayo*crispy u…' },
  { id: 'pbcustom-fresh', name: 'Fresh salmon bowl', price: 15.75, category: 'Custom bowls', description: 'Rijst*gemarineerde zalm* Avocado, komkommer, edamame, mango en tomaat*teriyaki en sir…' },
  { id: 'pbcustom-xl', name: 'The XL royal Bowl 🔥', price: 23.75, category: 'Custom bowls', description: 'Bodem met rijst daarop doen we kip,scampi,verse zalm en gerookte zalm en als groente avocado to…' },
  
  // Puree bowls
  { id: 'puree-small', name: 'Klein puree bowl', price: 11.00, category: 'Puree bowls', description: 'Aardappelpuree, fitbitesaus, gedroogde uitjes', unavailable: true },
  { id: 'puree-large', name: 'Grote puree bowl', price: 13.00, category: 'Puree bowls', description: 'Aardappelpuree, fitbitesaus, gedroogde uitjes', unavailable: true },
  
  // Korean fried chicken
  { id: 'kfc-sweetg-3', name: 'Korean fried chicken — sweet garlic (3 st)', price: 6.50, category: 'Korean fried chicken' },
  { id: 'kfc-sweetspicy-3', name: 'Korean fried chicken — sweet spicy (3 st)', price: 6.50, category: 'Korean fried chicken' },
  { id: 'kfc-sweetg-6', name: 'Korean fried chicken — sweet garlic (6 st)', price: 12.50, category: 'Korean fried chicken' },
  { id: 'kfc-sweetspicy-6', name: 'Korean fried chicken — spicy garlic (6 st)', price: 12.50, category: 'Korean fried chicken' },
  
  // Smoothies
  { id: 'smooth-red', name: 'Smoothie — Red fruits', price: 5.50, category: 'Smoothies' },
  { id: 'smooth-banana', name: 'Smoothie — Banaan aardbei', price: 5.50, category: 'Smoothies' },
  { id: 'smooth-mango', name: 'Smoothie — Banaan mango aardbei', price: 5.50, category: 'Smoothies' },
  { id: 'smooth-tropical', name: 'Smoothie Tropical', price: 5.50, category: 'Huisgemaakt smoothie' },
  { id: 'smooth-strawberry', name: 'Smoothie strawblina', price: 5.50, category: 'Huisgemaakt smoothie', description: 'Smoothie Aardbei Banaan' },
  { id: 'smooth-red-fruits', name: 'Smoothie red fruits', price: 5.50, category: 'Huisgemaakt smoothie', description: 'Smoothie bosbessen, aardbei, framboos' },
  { id: 'smooth-surprise', name: 'Surprise smoothie', price: 5.50, category: 'Huisgemaakt smoothie', description: 'Kun je niet kiezen? Laat het aan ons over! Wij mixen zelf een heerlijke combinatie van vers fr…' },
  
  // Drinks
  { id: 'drink-spa-blue', name: 'Spa blauw', price: 2.00, category: 'Koude dranken' },
  { id: 'drink-spa-red', name: 'Spa rood', price: 2.00, category: 'Koude dranken' },
  { id: 'drink-coke', name: 'Coca-Cola', price: 2.50, category: 'Koude dranken' },
  { id: 'drink-coke-zero', name: 'Coca-Cola zero', price: 2.50, category: 'Koude dranken' },
  { id: 'drink-ice-tea-spark', name: 'Ice tea sparkling', price: 2.50, category: 'Koude dranken' },
  { id: 'drink-ice-tea-peach', name: 'Ice tea peach', price: 2.50, category: 'Koude dranken' },
  { id: 'drink-redbull', name: 'Red Bull', price: 3.50, category: 'Koude dranken' },
  { id: 'drink-cecemel', name: 'Cecemel', price: 3.00, category: 'Koude dranken' },
  { id: 'drink-fristi', name: 'Fristi', price: 2.80, category: 'Koude dranken' },
  { id: 'drink-oasis-tropic', name: 'Oasis tropical', price: 2.50, category: 'Koude dranken' },
  { id: 'drink-oasis-framboos', name: 'Oasis framboos', price: 2.50, category: 'Koude dranken' },
  { id: 'drink-aa-orange', name: 'Oranje aa drink', price: 2.80, category: 'Koude dranken' },
  { id: 'drink-aa-lemon', name: 'Lemon aa drink', price: 3.00, category: 'Koude dranken' },
  { id: 'drink-aa-red', name: 'Red aa drink', price: 3.00, category: 'Koude dranken' },
  { id: 'drink-golden', name: 'Golden power', price: 1.50, category: 'Koude dranken' },
];

export const CUSTOMIZE_OPTIONS = {
  basis: [
    { id: 'basis-sushi', name: 'Witte sushirijst', price: 0 },
    { id: 'basis-bruin', name: 'Bruine rijst', price: 0 },
  ],
  veggies: [
    { id: 'veg-komkommer', name: 'Komkommer', price: 0 },
    { id: 'veg-tomaat', name: 'Tomaat', price: 0 },
    { id: 'veg-avocado', name: 'Avocado', price: 0 },
    { id: 'veg-mais', name: 'Maïs', price: 0.50 },
    { id: 'veg-mango', name: 'Mango', price: 0 },
    { id: 'veg-zeewier', name: 'Zeewier', price: 0 },
    { id: 'veg-edamame', name: 'Edamame', price: 0 },
    { id: 'veg-rodeui', name: 'Rode ui', price: 0 },
  ],
  toppings: [
    { id: 'topp-lente', name: 'Lente-ui', price: 0 },
    { id: 'topp-crispy', name: 'Crispy ui', price: 0 },
    { id: 'topp-nacho', name: "Nacho's", price: 0 },
    { id: 'topp-sesam', name: 'Sesam', price: 0 },
    { id: 'topp-gedroogde', name: 'Gedroogde uitjes', price: 0 },
  ],
  sauces: [
    { id: 'sauce-none', name: 'Zonder dressing', price: 0 },
    { id: 'sauce-mayo', name: 'Light mayo & light ketchup', price: 1.00 },
    { id: 'sauce-sriracha', name: 'Sriracha mayo', price: 0 },
    { id: 'sauce-teri', name: 'Teriyaki', price: 0 },
    { id: 'sauce-teri-sri', name: 'Teriyaki + sriracha mayo (aanrader)', price: 0.50 },
    { id: 'sauce-truffel', name: 'Truffel mayonnaise', price: 0 },
    { id: 'sauce-huisg', name: 'Huisgemaakt dyna saus', price: 0.50 },
  ],
};

export const DELIVERY_ZONES = {
  zone1: { name: 'Puurs, Willebroek, Boom', minOrder: 25 },
  zone2: { name: 'Bornem, Tisselt', minOrder: 30 },
  zone3: { name: 'Londerzeel, Niel-Schelle, Buggenhout', minOrder: 50 },
};

export const SHOP_INFO = {
  name: 'Fit Bite',
  address: 'Lichterstraat 68, 2870 Puurs-Sint-Amands',
  phone: '0494779216',
  tagline: 'Vers gemaakt, op maat ❤',
};
