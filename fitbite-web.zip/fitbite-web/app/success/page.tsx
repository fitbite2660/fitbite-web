'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import { SHOP_INFO } from '@/lib/products';
import styles from './page.module.css';

export default function Success() {
  const searchParams = useSearchParams();
  const orderId = searchParams.get('order');
  const [order, setOrder] = useState<any>(null);

  useEffect(() => {
    if (orderId) {
      const orderData = localStorage.getItem(`order-${orderId}`);
      if (orderData) {
        setOrder(JSON.parse(orderData));
      }
    }
  }, [orderId]);

  return (
    <main className={styles.success}>
      <div className="container">
        <div className={styles.card}>
          <div className={styles.icon}>✓</div>
          <h1>Bestelling geplaatst!</h1>
          <p className={styles.subtitle}>Dank je wel! Je bestelling is ontvangen.</p>

          {order && (
            <div className={styles.details}>
              <h2>Bestelgegevens</h2>
              <div className={styles.info}>
                <div className={styles.row}>
                  <span>Ordernummer:</span>
                  <strong>{order.orderId}</strong>
                </div>
                <div className={styles.row}>
                  <span>Totaalbedrag:</span>
                  <strong>€{order.total.toFixed(2)}</strong>
                </div>
                <div className={styles.row}>
                  <span>Bezorging:</span>
                  <strong>
                    {order.delivery.type === 'pickup'
                      ? 'Afhaling'
                      : `Bezorging naar ${order.delivery.address}`}
                  </strong>
                </div>
                <div className={styles.row}>
                  <span>Klant:</span>
                  <strong>{order.customer.name}</strong>
                </div>
              </div>

              <h2>Bestelitems</h2>
              <ul className={styles.items}>
                {order.items.map((item: any, idx: number) => (
                  <li key={idx}>
                    {item.quantity}x {item.name} — €{(item.price * item.quantity).toFixed(2)}
                  </li>
                ))}
              </ul>
            </div>
          )}

          <div className={styles.message}>
            <p>
              <strong>Wat nu?</strong>
            </p>
            <ul>
              <li>Je ontvangt een bevestigings-email met je bestelgegevens</li>
              <li>
                We bereiden je bestelling voor (⏱️ ongeveer 10-15 minuten)
              </li>
              <li>
                Bij vragen: bel {SHOP_INFO.phone} of kom langs op{' '}
                {SHOP_INFO.address}
              </li>
            </ul>
          </div>

          <Link href="/" className={styles.button}>
            Terug naar winkel
          </Link>
        </div>
      </div>
    </main>
  );
}
