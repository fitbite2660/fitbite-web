'use client';

import { create } from 'zustand';
import { Product } from './products';

export interface CartItem extends Product {
  cartId: string;
  quantity: number;
  customization?: {
    basis?: string;
    veggies?: string[];
    toppings?: string[];
    sauce?: string;
  };
}

interface CartStore {
  items: CartItem[];
  addItem: (product: Product, customization?: CartItem['customization']) => void;
  removeItem: (cartId: string) => void;
  updateQuantity: (cartId: string, quantity: number) => void;
  clearCart: () => void;
  getTotal: () => number;
  getItemCount: () => number;
}

export const useCartStore = create<CartStore>((set, get) => ({
  items: [],

  addItem: (product, customization) => {
    const cartId = `${product.id}-${Date.now()}`;
    set((state) => ({
      items: [
        ...state.items,
        {
          ...product,
          cartId,
          quantity: 1,
          customization,
        },
      ],
    }));
  },

  removeItem: (cartId) => {
    set((state) => ({
      items: state.items.filter((item) => item.cartId !== cartId),
    }));
  },

  updateQuantity: (cartId, quantity) => {
    if (quantity <= 0) {
      get().removeItem(cartId);
      return;
    }
    set((state) => ({
      items: state.items.map((item) =>
        item.cartId === cartId ? { ...item, quantity } : item
      ),
    }));
  },

  clearCart: () => {
    set({ items: [] });
  },

  getTotal: () => {
    const items = get().items;
    return items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  },

  getItemCount: () => {
    const items = get().items;
    return items.reduce((sum, item) => sum + item.quantity, 0);
  },
}));
