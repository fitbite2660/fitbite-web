'use client';

import Link from 'next/link';
import { useCartStore } from '@/lib/store';
import styles from './CartPreview.module.css';

export default function CartPreview() {
  const itemCount = useCartStore((state) => state.getItemCount());

  return (
    <Link href="/checkout" className={styles.cartButton}>
      <span className={styles.icon}>🛒</span>
      <span className={styles.text}>Winkelwagen</span>
      {itemCount > 0 && <span className={styles.badge}>{itemCount}</span>}
    </Link>
  );
}
