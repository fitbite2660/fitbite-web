'use client';

import { useState } from 'react';
import { CUSTOMIZE_OPTIONS, Product } from '@/lib/products';
import styles from './CustomizeModal.module.css';

interface CustomizeModalProps {
  product: Product;
  onSubmit: (customization: any) => void;
  onClose: () => void;
}

export default function CustomizeModal({
  product,
  onSubmit,
  onClose,
}: CustomizeModalProps) {
  const [basis, setBasis] = useState<string>(CUSTOMIZE_OPTIONS.basis[0].id);
  const [veggies, setVeggies] = useState<string[]>([]);
  const [toppings, setToppings] = useState<string[]>([]);
  const [sauce, setSauce] = useState<string>(CUSTOMIZE_OPTIONS.sauces[0].id);

  const handleVeggieToggle = (id: string) => {
    setVeggies((prev) =>
      prev.includes(id) ? prev.filter((v) => v !== id) : [...prev, id].slice(0, 3)
    );
  };

  const handleToppingToggle = (id: string) => {
    setToppings((prev) =>
      prev.includes(id) ? prev.filter((t) => t !== id) : [...prev, id].slice(0, 2)
    );
  };

  const handleSubmit = () => {
    onSubmit({
      basis,
      veggies,
      toppings,
      sauce,
    });
  };

  return (
    <div className={styles.overlay} onClick={onClose}>
      <div className={styles.modal} onClick={(e) => e.stopPropagation()}>
        <button className={styles.close} onClick={onClose}>
          ✕
        </button>

        <h2>{product.name}</h2>
        <p className={styles.subtitle}>Stel je bowl samen</p>

        {/* Basis */}
        <div className={styles.section}>
          <h3>Basis (kies 1)</h3>
          <div className={styles.options}>
            {CUSTOMIZE_OPTIONS.basis.map((opt) => (
              <label key={opt.id} className={styles.option}>
                <input
                  type="radio"
                  name="basis"
                  value={opt.id}
                  checked={basis === opt.id}
                  onChange={() => setBasis(opt.id)}
                />
                <span>{opt.name}</span>
                {opt.price > 0 && <span className={styles.price}>+€{opt.price.toFixed(2)}</span>}
              </label>
            ))}
          </div>
        </div>

        {/* Groenten */}
        <div className={styles.section}>
          <h3>Groenten (max 3)</h3>
          <div className={styles.options}>
            {CUSTOMIZE_OPTIONS.veggies.map((opt) => (
              <label key={opt.id} className={styles.option}>
                <input
                  type="checkbox"
                  checked={veggies.includes(opt.id)}
                  onChange={() => handleVeggieToggle(opt.id)}
                />
                <span>{opt.name}</span>
                {opt.price > 0 && <span className={styles.price}>+€{opt.price.toFixed(2)}</span>}
              </label>
            ))}
          </div>
          <p className={styles.count}>{veggies.length}/3 geselecteerd</p>
        </div>

        {/* Toppings */}
        <div className={styles.section}>
          <h3>Toppings (max 2)</h3>
          <div className={styles.options}>
            {CUSTOMIZE_OPTIONS.toppings.map((opt) => (
              <label key={opt.id} className={styles.option}>
                <input
                  type="checkbox"
                  checked={toppings.includes(opt.id)}
                  onChange={() => handleToppingToggle(opt.id)}
                />
                <span>{opt.name}</span>
              </label>
            ))}
          </div>
          <p className={styles.count}>{toppings.length}/2 geselecteerd</p>
        </div>

        {/* Sauzen */}
        <div className={styles.section}>
          <h3>Saus (kies 1)</h3>
          <div className={styles.options}>
            {CUSTOMIZE_OPTIONS.sauces.map((opt) => (
              <label key={opt.id} className={styles.option}>
                <input
                  type="radio"
                  name="sauce"
                  value={opt.id}
                  checked={sauce === opt.id}
                  onChange={() => setSauce(opt.id)}
                />
                <span>{opt.name}</span>
                {opt.price > 0 && <span className={styles.price}>+€{opt.price.toFixed(2)}</span>}
              </label>
            ))}
          </div>
        </div>

        {/* Actions */}
        <div className={styles.actions}>
          <button className={styles.btnSecondary} onClick={onClose}>
            Sluiten
          </button>
          <button className={styles.btnPrimary} onClick={handleSubmit}>
            Toevoegen aan winkelwagen (€{product.price.toFixed(2)})
          </button>
        </div>
      </div>
    </div>
  );
}
