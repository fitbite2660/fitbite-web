# Fit Bite - Online Winkel

Professionele e-commerce website voor Fit Bite gemaakt met Next.js en SumUp betaling.

## 🚀 Snelle Start

### 1. Installatie

```bash
# Clone het project
git clone <jouw-repo-url>
cd fitbite-web

# Installeer dependencies
npm install
```

### 2. Omgevingsvariabelen

Maak een `.env.local` bestand aan:

```env
NEXT_PUBLIC_SUMUP_MERCHANT_ID=M5VYY878
SUMUP_API_TOKEN=YOUR_SUMUP_API_TOKEN_HERE
```

**Waar vind je je SumUp API Token?**
1. Ga naar [SumUp Dashboard](https://dashboard.sumup.com)
2. Ga naar **Settings → API**
3. Kopieer je API Token
4. Plak deze in `.env.local`

### 3. Lokaal testen

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in je browser.

## 📱 Functionaliteiten

✅ **Volledige product catalogus** - Alle menu items van Fit Bite
✅ **Custom pokébowls** - Klanten kiezen basis, groenten, toppings en saus
✅ **Shopping cart** - Toevoegen, verwijderen, hoeveelheden wijzigen
✅ **Bezorgzones** - Puurs, Willebroek, Boom (€25+), Bornem/Tisselt (€30+), Londerzeel/Niel-Schelle/Buggenhout (€50+)
✅ **SumUp betaling** - Veilige online betaling via Bancontact, Payconiq, kaart
✅ **Bestellingsbeheer** - Klanten zien hun bestelingen
✅ **Responsive design** - Perfect op telefoon, tablet en computer
✅ **PWA** - Installeerbaar als app op telefoon

## 🌐 Deployment op Netlify

### Stap 1: Push naar GitHub

```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/jouwusername/fitbite-web.git
git push -u origin main
```

### Stap 2: Connect met Netlify

1. Ga naar [netlify.com](https://netlify.com)
2. Sign up / Log in
3. Klik "New site from Git"
4. Selecteer je GitHub repo
5. Build command: `npm run build`
6. Publish directory: `.next`
7. Klik "Deploy"

### Stap 3: Voeg omgevingsvariabelen toe

In Netlify:
1. Ga naar **Settings → Build & Deploy → Environment**
2. Add variables:
   - `NEXT_PUBLIC_SUMUP_MERCHANT_ID` = `M5VYY878`
   - `SUMUP_API_TOKEN` = (je SumUp API token)

### Stap 4: Koppel je domein

1. Koop een domein (bijv. fitbite.be op Namecheap, 1&1, etc.)
2. In Netlify: **Domain management**
3. Voeg domein toe en volg de DNS instructies

## 💳 SumUp Setup

### API Token Aanmaken

1. [Login SumUp](https://dashboard.sumup.com)
2. **Settings → Integrations → API Access**
3. Genereer een API token
4. Voeg toe aan `.env.local`

### Test modus

Voor testen kun je testkaarten gebruiken:
- Nummer: `4111 1111 1111 1111`
- CVC: `123`
- Vervaldatum: `12/25`

## 📊 Bestellingen bijhouden

Bestellingen worden opgeslagen in `localStorage` (browser opslag). Voor productie raden we aan een database toe te voegen (Firebase, Supabase, etc.).

### Database toevoegen (optioneel)

Neem contact op als je een database wilt toevoegen voor:
- Persistente bestellingsopslag
- Admin dashboard
- Email notificaties
- Inventaris tracking

## 🛠️ Aanpassingen

### Menu updaten
Edit `lib/products.ts` - voeg/wijzig producten, prijzen, categorieën

### Bezorgzones wijzigen
Edit `lib/products.ts` - `DELIVERY_ZONES` object

### Styling aanpassen
- Kleuren: `app/globals.css` `:root` variabelen
- Per-component styles: `.module.css` bestanden

### SumUp merchant ID veranderen
Edit `lib/sumup.ts` en `.env.local`

## 📞 Support

**Fit Bite Contact:**
- 📍 Lichterstraat 68, 2870 Puurs-Sint-Amands
- 📱 0494 77 92 16
- 🌐 www.fitbite.be

## 📝 Projectstructuur

```
fitbite-web/
├── app/
│   ├── page.tsx              # Homepage
│   ├── checkout/page.tsx     # Checkout pagina
│   ├── success/page.tsx      # Bevestigingspagina
│   ├── layout.tsx            # Root layout
│   └── *.module.css          # Component styles
├── components/
│   ├── ProductCard.tsx
│   ├── CartPreview.tsx
│   ├── CustomizeModal.tsx
│   ├── CartSummary.tsx
│   └── *.module.css
├── lib/
│   ├── products.ts           # Product & zone data
│   ├── store.ts              # Zustand cart store
│   └── sumup.ts              # SumUp API integratie
├── public/
│   └── manifest.json         # PWA manifest
├── package.json
├── tsconfig.json
├── next.config.js
└── README.md
```

## 🚀 TODO (Toekomstige features)

- [ ] Email notificaties voor bestellingen
- [ ] Admin dashboard
- [ ] Inventaris tracking
- [ ] Speciale aanbiedingen/kortingen
- [ ] Klantbeoordelingen
- [ ] Google Maps integratie
- [ ] Favorieten/wishlist

---

**Gemaakt met ❤️ voor Fit Bite**
