'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useCartStore, CartItem } from '@/lib/store';
import { DELIVERY_ZONES, SHOP_INFO } from '@/lib/products';
import { createSumUpCheckout, generateCheckoutReference, MERCHANT_ID } from '@/lib/sumup';
import CartSummary from '@/components/CartSummary';
import styles from './page.module.css';

type DeliveryType = 'pickup' | 'delivery';

export default function Checkout() {
  const cart = useCartStore((state) => state.items);
  const cartTotal = useCartStore((state) => state.getTotal());
  const clearCart = useCartStore((state) => state.clearCart);

  const [delivery, setDelivery] = useState<DeliveryType>('pickup');
  const [zone, setZone] = useState<string>('zone1');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const deliveryZone = delivery === 'delivery' ? DELIVERY_ZONES[zone as keyof typeof DELIVERY_ZONES] : null;
  const deliveryPrice = delivery === 'delivery' ? deliveryZone?.minOrder || 0 : 0;
  const subtotal = cartTotal + deliveryPrice;

  const handleCheckout = async () => {
    // Validation
    if (!name.trim()) {
      setError('Gelieve uw naam in te voeren');
      return;
    }
    if (!email.trim()) {
      setError('Gelieve uw email in te voeren');
      return;
    }
    if (!phone.trim()) {
      setError('Gelieve uw telefoonnummer in te voeren');
      return;
    }
    if (delivery === 'delivery' && !address.trim()) {
      setError('Gelieve uw adres in te voeren');
      return;
    }

    setLoading(true);
    setError('');

    try {
      const orderId = `order-${Date.now()}`;
      const cartSummary = cart
        .map((item) => `${item.quantity}x ${item.name} (€${(item.price * item.quantity).toFixed(2)})`)
        .join(', ');

      const checkoutRef = generateCheckoutReference(orderId);

      const response = await createSumUpCheckout({
        amount: Math.round(subtotal * 100),
        currency: 'EUR',
        checkout_reference: checkoutRef,
        pay_to_email: MERCHANT_ID === 'M5VYY878' ? 'vincent.meert@gmail.com' : 'info@fitbite.be',
        customer_email: email,
        customer_phone: phone,
        return_url: `${window.location.origin}/success?order=${orderId}`,
        decline_url: `${window.location.origin}/checkout`,
        description: `Fit Bite Bestelling - ${cartSummary}`,
      });

      // Save order locally (in production, use a database)
      localStorage.setItem(
        `order-${orderId}`,
        JSON.stringify({
          orderId,
          items: cart,
          total: subtotal,
          delivery: { type: delivery, zone, address },
          customer: { name, email, phone },
          notes,
          createdAt: new Date().toISOString(),
        })
      );

      // Redirect to SumUp checkout
      window.location.href = response.checkout_url;
      clearCart();
    } catch (err) {
      console.error('Checkout error:', err);
      setError(err instanceof Error ? err.message : 'Er is iets fout gegaan. Probeer opnieuw.');
      setLoading(false);
    }
  };

  if (cart.length === 0) {
    return (
      <main className={styles.checkout}>
        <div className="container">
          <Link href="/" className={styles.back}>
            ← Terug naar winkel
          </Link>
          <div className={styles.empty}>
            <p>Je winkelwagen is leeg</p>
            <Link href="/" className="btn-primary">
              Start winkelenמ
            </Link>
          </div>
        </div>
      </main>
    );
  }

  return (
    <main className={styles.checkout}>
      <div className="container">
        <Link href="/" className={styles.back}>
          ← Terug naar winkel
        </Link>

        <h1 className={styles.title}>Jouw Bestelling</h1>

        <div className={styles.grid}>
          {/* Order Summary */}
          <div className={styles.summary}>
            <CartSummary />

            <div className={styles.prices}>
              <div className={styles.priceRow}>
                <span>Producten:</span>
                <span>€{cartTotal.toFixed(2)}</span>
              </div>
              {delivery === 'delivery' && (
                <div className={styles.priceRow}>
                  <span>Bezorging:</span>
                  <span>€{deliveryPrice.toFixed(2)}</span>
                </div>
              )}
              <div className={`${styles.priceRow} ${styles.total}`}>
                <span>Totaal:</span>
                <span>€{subtotal.toFixed(2)}</span>
              </div>
            </div>
          </div>

          {/* Form */}
          <div className={styles.form}>
            <h2>Bestelgegevens</h2>

            {error && <div className={styles.error}>{error}</div>}

            {/* Customer Info */}
            <div className={styles.section}>
              <label>
                Voornaam & Achternaam *
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Jouw naam"
                />
              </label>
              <label>
                Email *
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="jouw@email.com"
                />
              </label>
              <label>
                Telefoonnummer *
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="0494 77 92 16"
                />
              </label>
            </div>

            {/* Delivery Options */}
            <div className={styles.section}>
              <h3>Afhaling of Bezorging?</h3>
              <label className={styles.radioLabel}>
                <input
                  type="radio"
                  name="delivery"
                  value="pickup"
                  checked={delivery === 'pickup'}
                  onChange={() => setDelivery('pickup')}
                />
                <span>Afhaling</span>
                <small>{SHOP_INFO.address}</small>
              </label>

              <label className={styles.radioLabel}>
                <input
                  type="radio"
                  name="delivery"
                  value="delivery"
                  checked={delivery === 'delivery'}
                  onChange={() => setDelivery('delivery')}
                />
                <span>Bezorging naar huis</span>
              </label>

              {delivery === 'delivery' && (
                <>
                  <label>
                    Welk gebied? *
                    <select value={zone} onChange={(e) => setZone(e.target.value)}>
                      {Object.entries(DELIVERY_ZONES).map(([key, z]) => (
                        <option key={key} value={key}>
                          {z.name} (€{z.minOrder}+)
                        </option>
                      ))}
                    </select>
                  </label>
                  <label>
                    Adres *
                    <input
                      type="text"
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                      placeholder="Straatnaam 123, Postcode Plaats"
                    />
                  </label>
                </>
              )}
            </div>

            {/* Notes */}
            <div className={styles.section}>
              <label>
                Opmerkingen
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Bijv. allergieën, voorkeur, etc."
                  rows={3}
                />
              </label>
            </div>

            {/* Checkout Button */}
            <button
              className={`${styles.btnCheckout} ${loading ? styles.loading : ''}`}
              onClick={handleCheckout}
              disabled={loading}
            >
              {loading ? 'Laden...' : `Betalen €${subtotal.toFixed(2)}`}
            </button>

            <p className={styles.powered}>
              💳 Veilig betalen via SumUp
            </p>
          </div>
        </div>
      </div>
    </main>
  );
}
