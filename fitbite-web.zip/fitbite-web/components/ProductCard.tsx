'use client';

import { Product } from '@/lib/products';
import styles from './ProductCard.module.css';

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product) => void;
}

export default function ProductCard({ product, onAddToCart }: ProductCardProps) {
  const handleClick = () => {
    if (!product.unavailable) {
      onAddToCart(product);
    }
  };

  return (
    <div
      className={`${styles.card} ${product.unavailable ? styles.unavailable : ''}`}
      onClick={handleClick}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          handleClick();
        }
      }}
    >
      <p className={styles.category}>{product.category}</p>
      <h3 className={styles.name}>{product.name}</h3>
      {product.description && (
        <p className={styles.description}>{product.description.substring(0, 50)}...</p>
      )}
      <div className={styles.footer}>
        <span className={styles.price}>€{product.price.toFixed(2)}</span>
        <span className={styles.icon}>
          {product.unavailable ? '❌' : product.customizable ? '✨' : '➕'}
        </span>
      </div>
    </div>
  );
}
